# app/controllers/api/v1/auth/registrations_controller.rb
# frozen_string_literal: true

module Api
  module V1
    module Auth
      class RegistrationsController < Devise::RegistrationsController
        include ActionController::MimeResponds

        prepend_before_action -> { request.env['devise.mapping'] = Devise.mappings[:amigo] }
        respond_to :json
        skip_before_action :authenticate_amigo!, raise: false

        # POST /api/v1/signup
        def create
          build_resource(sign_up_params)

          if resource.save
            render json: {
              status: { code: 201, message: 'Signed up successfully.' },
              data:   { amigo: resource.slice(:id, :user_name, :email, :first_name, :last_name) }
            }, status: :created
          else
            Rails.logger.warn "Signup failed: #{resource.errors.full_messages.join(', ')}"
            render json: {
              status: { code: 422, message: 'Unprocessable Entity' },
              errors: resource.errors.full_messages
            }, status: :unprocessable_entity
          end
        end

        private

        # Only the essentials at signup
        def sign_up_params
          params.require(:amigo).permit(
            :first_name, :last_name, :user_name, :email,
            :password, :password_confirmation, :avatar
          )
        end
      end
    end
  end
end
