# config/initializers/action_mailer.rb
Rails.application.configure do
  config.action_mailer.perform_deliveries = true
  config.action_mailer.raise_delivery_errors = true

  config.action_mailer.delivery_method = :smtp
  config.action_mailer.smtp_settings = {
    address:              "smtp.sendgrid.net",
    port:                 587,
    domain:               "sagacicweb.com",
    user_name:            "apikey", # literal per SendGrid
    password:             Rails.application.credentials.dig(:sendgrid, :api_key),
    authentication:       :plain,
    enable_starttls_auto: true,
    open_timeout:         5,   # optional, nice during debugging
    read_timeout:         5    # optional, nice during debugging
  }

  # Optional: log SMTP interaction to Rails log
  config.action_mailer.logger = Rails.logger
end
