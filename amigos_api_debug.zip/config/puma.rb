# config/puma.rb
require "etc"

# —————————————————————————————————————————————
# 1) Threads & workers sized from CPU
cpu_count   = Etc.nprocessors
min_threads = ENV.fetch("RAILS_MIN_THREADS", "1").to_i
max_threads = ENV.fetch("RAILS_MAX_THREADS", cpu_count.to_s).to_i
max_workers = ENV.fetch("PUMA_MAX_WORKERS", (cpu_count / 3).to_s).to_i

puts "Detected #{cpu_count} CPU cores"
puts "Puma threads: #{min_threads}-#{max_threads}, workers: #{max_workers}"

threads min_threads, max_threads

# —————————————————————————————————————————————
# 2) Environment
env = ENV.fetch("RAILS_ENV", "development")
environment env

# —————————————————————————————————————————————
# 3) Bindings per environment
if env == "development"
  # Long timeout for dev
  worker_timeout 3600

  # SSL on 3001 with local certs (relative to Rails.root)
  ssl_bind "0.0.0.0", "3001",
           cert: Rails.root.join("localhost+2.pem").to_s,
           key:  Rails.root.join("localhost+2-key.pem").to_s,
           verify_mode: "none"

  # Important: do NOT call `port` here, or you’ll also open plain HTTP.

else
  # Clustered workers in non-dev
  workers max_workers
  preload_app!

  on_worker_boot do
    ActiveRecord::Base.establish_connection if defined?(ActiveRecord)
  end

  # Plain HTTP in non-dev (use $PORT or default 3001)
  port ENV.fetch("PORT", "3001")
end

# —————————————————————————————————————————————
# 4) Allow `bin/rails restart`
plugin :tmp_restart
