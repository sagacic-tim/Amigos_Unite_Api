class Api::V1::EventsController < ApplicationController
  include ErrorHandling  # For handling common ActiveRecord errors
  before_action :authenticate_amigo!, except: [:index, :show, :mission_index]
  before_action :debug_authentication
  before_action :set_event, only: [:show, :update, :destroy]
  rescue_from ActiveRecord::RecordNotFound, with: :handle_standard_error
  rescue_from StandardError, with: :handle_standard_error

  # GET /api/v1/events
  def index
    @events = Event.all
    render :index
  rescue ActiveRecord::ConnectionNotEstablished => e
    render json: { error: 'Database connection error.' }, status: :service_unavailable
  rescue StandardError => e
    render json: { error: e.message }, status: :internal_server_error
  end

  # GET /api/v1/events/:id 
  def show
    render :show  # Assuming @event is set by set_event and exists
  end 
  
  # POST /api/v1/events
  def create
    policy = EventPolicy.new(current_amigo, nil)
    return render json: { error: "Unauthorized" }, status: :unauthorized unless policy.create?

    event = Events::CreateEvent.new.call(
      creator: current_amigo,
      attrs: event_params
    )

    render json: { id: event.id, event_name: event.event_name, event_date: event.event_date, event_time: event.event_time,
                   lead_coordinator_id: event.lead_coordinator_id },
           status: :created
  rescue ActiveRecord::RecordInvalid => e
    render json: { errors: event&.errors&.full_messages || [e.message] }, status: :unprocessable_entity
  end

  # PATCH/PUT /api/v1/events/:id

  def update
    authorize_event!(@event, :update?)

    Event.transaction do
      if params[:new_lead_coordinator_id].present?
        new_id = params[:new_lead_coordinator_id].to_i

        # Remove any existing lead row that isn't the new one, then upsert the new lead
        @event.event_amigo_connectors.lead_coordinator.where.not(amigo_id: new_id).delete_all
        @event.event_amigo_connectors.find_or_initialize_by(amigo_id: new_id).update!(role: :lead_coordinator)
        @event.update!(lead_coordinator_id: new_id)
      end

      @event.update!(event_params)
    end

    render :update
  rescue ActiveRecord::RecordInvalid => e
    render json: { error: e.record.errors.full_messages }, status: :unprocessable_entity
  end

  
  # DELETE /api/v1/events/:id
  def destroy
    authorize_event!(@event, :destroy?)
    if @event.destroy
      render json: { message: "Event successfully deleted." }, status: :ok
    else
      render json: { error: @event.errors.full_messages.to_sentence }, status: :unprocessable_entity
    end
  rescue ActiveRecord::RecordNotFound => e
    render json: { error: "Event not found." }, status: :not_found
  rescue => e
    render json: { error: e.message }, status: :internal_server_error
  end   

  # GET /api/v1/events/mission
  def mission_index
    # This is a hypothetical action; you'll need to define what data to show
    render 'api/v1/events/mission_index'
  end

  private

  def debug_authentication
    Rails.logger.info "Current User: #{current_amigo.inspect}"
    Rails.logger.info "Authorization Header: #{request.headers['Authorization']}"
  end

  def set_event
    @event = Event.find(params[:id])
  end 

  def handle_standard_error(e)
    if action_name == 'show' && e.is_a?(ActiveRecord::RecordNotFound)
      render json: { error: "Event with ID #{params[:id]} doesn't exist." }, status: :not_found
    else
      render json: { error: e.message }, status: :internal_server_error
    end
  end

  def event_params
    params.require(:event).permit(
      :event_name,
      :event_type,
      :event_date,
      :event_time,
      event_speakers_performers: []
    )
  end

  # Minimal policy invoker without bringing in Pundit
  def authorize_event!(record, action)
    policy = EventPolicy.new(current_amigo, record)
    ok = policy.public_send(action)
    return if ok
    render json: { error: "Unauthorized" }, status: :unauthorized and return
  end
end
